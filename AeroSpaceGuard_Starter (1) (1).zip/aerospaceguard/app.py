import math
from datetime import datetime, timezone

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st

st.set_page_config(page_title="AeroSpaceGuard", page_icon="✈️", layout="wide")

NOAA = "https://services.swpc.noaa.gov"
AIRPORTS = {
    "London Heathrow (LHR)": (51.4700, -0.4543),
    "New York JFK (JFK)": (40.6413, -73.7781),
    "Kochi (COK)": (10.1520, 76.4019),
    "Delhi (DEL)": (28.5562, 77.1000),
    "Singapore (SIN)": (1.3644, 103.9915),
    "Dubai (DXB)": (25.2532, 55.3657),
    "Tokyo Haneda (HND)": (35.5494, 139.7798),
    "Sydney (SYD)": (-33.9399, 151.1753),
    "Anchorage (ANC)": (61.1743, -149.9985),
    "Reykjavik Keflavik (KEF)": (63.9850, -22.6056),
}


def get_json(path):
    url = f"{NOAA}/{path}"
    try:
        response = requests.get(url, timeout=12, headers={"User-Agent": "AeroSpaceGuard-student-prototype/1.0"})
        response.raise_for_status()
        return response.json(), None
    except Exception as exc:
        return None, f"Could not retrieve {path}: {exc}"


def as_records(data):
    """Normalise NOAA JSON arrays, including older header-row formats."""
    if not isinstance(data, list) or not data:
        return []
    if isinstance(data[0], dict):
        return data
    if isinstance(data[0], list):
        headers = data[0]
        return [dict(zip(headers, row)) for row in data[1:] if isinstance(row, list)]
    return []


def latest_kp():
    data, error = get_json("products/noaa-planetary-k-index.json")
    records = as_records(data)
    if records:
        for row in reversed(records):
            value = row.get("kp_index", row.get("kp", row.get("Kp")))
            try:
                return float(value), row.get("time_tag", row.get("time", "Unknown")), error
            except (TypeError, ValueError):
                continue
    return None, None, error or "No Kp records returned."


def latest_xray():
    data, error = get_json("json/goes/primary/xrays-1-day.json")
    records = as_records(data)
    candidates = []
    for row in records:
        energy = str(row.get("energy", ""))
        if "0.1-0.8" in energy:
            try:
                candidates.append((float(row.get("flux", 0)), row.get("time_tag", "Unknown")))
            except (TypeError, ValueError):
                pass
    if candidates:
        return candidates[-1][0], candidates[-1][1], error
    return None, None, error or "No X-ray records returned."


def latest_proton():
    data, error = get_json("json/goes/primary/integral-protons-1-day.json")
    records = as_records(data)
    candidates = []
    for row in records:
        energy = str(row.get("energy", ""))
        if ">=10" in energy or ">10" in energy:
            try:
                candidates.append((float(row.get("flux", 0)), row.get("time_tag", "Unknown")))
            except (TypeError, ValueError):
                pass
    if candidates:
        return candidates[-1][0], candidates[-1][1], error
    return None, None, error or "No proton records returned."


def xray_class(flux):
    if flux is None or flux <= 0:
        return "Unavailable"
    if flux >= 1e-4:
        return f"X{flux / 1e-4:.1f}"
    if flux >= 1e-5:
        return f"M{flux / 1e-5:.1f}"
    if flux >= 1e-6:
        return f"C{flux / 1e-6:.1f}"
    if flux >= 1e-7:
        return f"B{flux / 1e-7:.1f}"
    return "A-level"


def clamp(value):
    return max(0, min(100, int(round(value))))


def risk_label(score):
    if score < 25:
        return "Low", "🟢"
    if score < 50:
        return "Moderate", "🟡"
    if score < 75:
        return "Elevated", "🟠"
    return "High", "🔴"


def route_points(start, end, steps=50):
    # Simple interpolation is adequate for this demonstrator, not flight planning.
    lat1, lon1 = start
    lat2, lon2 = end
    delta_lon = ((lon2 - lon1 + 180) % 360) - 180
    lats = [lat1 + (lat2 - lat1) * i / (steps - 1) for i in range(steps)]
    lons = [((lon1 + delta_lon * i / (steps - 1) + 180) % 360) - 180 for i in range(steps)]
    return lats, lons


def build_route_map(start_name, end_name, risk):
    start, end = AIRPORTS[start_name], AIRPORTS[end_name]
    lats, lons = route_points(start, end)
    fig = go.Figure()
    fig.add_trace(go.Scattergeo(lon=lons, lat=lats, mode="lines", line=dict(width=4, color="#38bdf8"), name="Illustrative route"))
    fig.add_trace(go.Scattergeo(lon=[start[1], end[1]], lat=[start[0], end[0]], mode="markers+text",
                                text=[start_name.split("(")[0].strip(), end_name.split("(")[0].strip()],
                                textposition="top center", marker=dict(size=9, color="#f8fafc"), name="Airports"))
    fig.update_geos(showland=True, landcolor="#1e293b", showocean=True, oceancolor="#0b1220",
                    showcountries=True, countrycolor="#475569", showcoastlines=True, coastlinecolor="#64748b",
                    projection_type="orthographic")
    fig.update_layout(height=430, margin=dict(l=0, r=0, t=10, b=0), paper_bgcolor="#0b1220",
                      font_color="#e2e8f0", legend=dict(orientation="h", y=0.02))
    return fig


st.markdown("""
<style>
.stApp {background: #07111f; color: #e5edf7;}
.block-container {padding-top: 1.4rem; max-width: 1250px;}
[data-testid="stMetric"] {background: #111f33; border: 1px solid #263b55; padding: 13px; border-radius: 12px;}
div[data-testid="stAlert"] {border-radius: 10px;}
</style>
""", unsafe_allow_html=True)

st.title("✈️ AeroSpaceGuard")
st.caption("Space-weather intelligence for aviation · Student prototype · Not for operational flight decisions")

with st.sidebar:
    st.header("Flight scenario")
    start_name = st.selectbox("Departure", list(AIRPORTS.keys()), index=0)
    end_options = [name for name in AIRPORTS if name != start_name]
    end_name = st.selectbox("Destination", end_options, index=1 if len(end_options) > 1 else 0)
    altitude = st.select_slider("Cruising altitude (feet)", options=[25000, 30000, 35000, 40000, 45000], value=35000)
    st.divider()
    mode = st.radio("Data mode", ["Live NOAA data", "Simulated scenarios"], index=0)
    scenario = "Moderate geomagnetic storm"
    if mode == "Simulated scenarios":
        scenario = st.selectbox("Choose demonstration scenario", ["Quiet conditions", "Moderate geomagnetic storm", "Severe solar event"])
    st.caption("Live feeds are fetched from NOAA SWPC. Simulated scenarios are fictional demonstrations.")

with st.spinner("Retrieving space-weather data…"):
    kp_live, kp_time, kp_error = latest_kp()
    xray_live, xray_time, xray_error = latest_xray()
    proton_live, proton_time, proton_error = latest_proton()

if mode == "Simulated scenarios":
    presets = {
        "Quiet conditions": (2.0, 2e-7, 0.5),
        "Moderate geomagnetic storm": (6.0, 2e-5, 12.0),
        "Severe solar event": (8.0, 2e-4, 1500.0),
    }
    kp, xray, proton = presets[scenario]
    data_status = f"SIMULATED · {scenario}"
else:
    kp, xray, proton = kp_live, xray_live, proton_live
    data_status = "LIVE NOAA FEEDS" if all(v is not None for v in [kp, xray, proton]) else "PARTIAL LIVE DATA"

# If a feed is unavailable, preserve the dashboard and clearly identify the missing input.
if kp is None:
    kp = 0.0
if xray is None:
    xray = 0.0
if proton is None:
    proton = 0.0

start_coord, end_coord = AIRPORTS[start_name], AIRPORTS[end_name]
max_lat = max(abs(start_coord[0]), abs(end_coord[0]))
latitude_factor = min(1.0, max(0.0, (max_lat - 25) / 55))
altitude_factor = max(0.7, min(1.25, altitude / 35000))

# Transparent demonstration heuristics, not validated aviation prediction models.
hf_score = clamp((kp / 9) * 48 + (min(xray / 1e-4, 1) * 35) + latitude_factor * 17)
gnss_score = clamp((kp / 9) * 45 + latitude_factor * 40 + (min(xray / 1e-4, 1) * 15))
radiation_score = clamp((min(proton / 1000, 1) * 75 + latitude_factor * 15 + (altitude_factor - 0.7) * 33))

st.markdown(f"**DATA STATUS:** `{data_status}`　 ·　 **Updated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
if mode == "Live NOAA data" and any(v is None for v in [kp_live, xray_live, proton_live]):
    st.warning("One or more NOAA feeds could not be read. Missing inputs are temporarily shown as zero for this prototype; check the feed status below. Do not interpret the resulting scores as a complete assessment.")

m1, m2, m3, m4 = st.columns(4)
m1.metric("Planetary Kp", f"{kp:.1f}", help="Global geomagnetic activity indicator; not a local route measurement.")
m2.metric("GOES X-ray class", xray_class(xray))
m3.metric("GOES proton flux", f"{proton:.2g} pfu", help="Approximate >=10 MeV channel where available.")
m4.metric("Flight altitude", f"{altitude:,} ft")

st.subheader("Flight-specific prototype risk estimates")
r1, r2, r3 = st.columns(3)
for col, title, score, detail in [
    (r1, "HF communication", hf_score, "Solar radio blackout and geomagnetic context"),
    (r2, "GNSS navigation", gnss_score, "Geomagnetic and latitude screening proxy"),
    (r3, "Radiation environment", radiation_score, "GOES proton-flux screening proxy"),
]:
    label, emoji = risk_label(score)
    col.metric(title, f"{emoji} {label}", f"Prototype score: {score}/100")
    col.progress(score / 100)
    col.caption(detail)

left, right = st.columns([1.2, 1])
with left:
    st.subheader("Illustrative flight corridor")
    st.plotly_chart(build_route_map(start_name, end_name, max(hf_score, gnss_score, radiation_score)), use_container_width=True)
    st.caption("The line is a simplified great-circle-style illustration, not a navigable route or actual flight track.")
with right:
    st.subheader("Aviation impact briefing")
    top_risk = max([(hf_score, "HF communication"), (gnss_score, "GNSS navigation"), (radiation_score, "radiation environment")])
    st.write(f"**Highest screening indicator:** {top_risk[1]} ({top_risk[0]}/100).")
    if mode == "Simulated scenarios":
        st.info("This result uses a fictional scenario selected for demonstration. It is not a live event or forecast.")
    else:
        st.info("This is a heuristic screening estimate from global space-weather indicators. It does not predict an actual disruption on this route.")
    if hf_score >= 50:
        st.write("• Review official HF communication advisories and available communication procedures.")
    if gnss_score >= 50:
        st.write("• Review official GNSS integrity information and applicable navigation contingency procedures.")
    if radiation_score >= 50:
        st.write("• Consult official radiation advisories and qualified aviation radiation guidance.")
    if max(hf_score, gnss_score, radiation_score) < 50:
        st.write("• Continue monitoring official space-weather and aviation advisories.")
    st.write("• Operational decisions must remain with qualified airline dispatchers, pilots and authorities.")

st.subheader("Risk score breakdown")
breakdown = pd.DataFrame({"Hazard": ["HF communication", "GNSS navigation", "Radiation environment"],
                           "Prototype score": [hf_score, gnss_score, radiation_score]})
chart = go.Figure(go.Bar(x=breakdown["Prototype score"], y=breakdown["Hazard"], orientation="h",
                         marker_color=["#38bdf8", "#a78bfa", "#f59e0b"], text=breakdown["Prototype score"], textposition="outside"))
chart.update_layout(xaxis=dict(range=[0, 110], title="Illustrative score (0–100)"), height=250,
                    margin=dict(l=10, r=30, t=10, b=10), paper_bgcolor="#07111f", plot_bgcolor="#07111f",
                    font_color="#e2e8f0")
st.plotly_chart(chart, use_container_width=True)

with st.expander("NOAA feed status and source timestamps"):
    st.write({"Planetary K-index": {"value": kp_live, "timestamp": kp_time, "error": kp_error},
              "GOES X-ray": {"value": xray_live, "timestamp": xray_time, "error": xray_error},
              "GOES proton": {"value": proton_live, "timestamp": proton_time, "error": proton_error}})
    st.markdown("Sources: [NOAA SWPC data access](https://www.swpc.noaa.gov/content/data-access) · [Planetary K-index](https://www.spaceweather.gov/products/planetary-k-index)")

st.divider()
st.caption("AeroSpaceGuard is an educational demonstration. Its scoring formulas are transparent, unvalidated heuristics—not machine-learning predictions, official NOAA/ICAO risk levels, radiation-dose calculations, flight planning, or safety advice.")
