# AeroSpaceGuard — 48-hour student prototype

A responsive Streamlit web app designed to run in desktop and mobile browsers. It fetches selected live NOAA SWPC feeds and includes clearly labelled simulated scenarios.

## 1. Install

Install Python 3.11 or newer from https://www.python.org/downloads/ . On Windows, tick **Add Python to PATH** during installation.

Install Visual Studio Code from https://code.visualstudio.com/ .

## 2. Open the project

Extract the ZIP, open the `aerospaceguard` folder in VS Code, then open Terminal → New Terminal.

## 3. Create a virtual environment (Windows PowerShell)

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt instead:

```cmd
py -3.11 -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Run

```powershell
python -m streamlit run app.py
```

Open the local URL printed in the terminal, usually http://localhost:8501 .

## 5. Test on a phone on the same Wi-Fi

Run:

```powershell
python -m streamlit run app.py --server.address 0.0.0.0
```

Find your computer's local IPv4 address using `ipconfig`, then open `http://YOUR-IP:8501` on the phone. Both devices must be on the same Wi-Fi; allow Python through the firewall if prompted.

## 6. Deploy for access anywhere

Push this folder to a GitHub repository. Create a Streamlit Community Cloud app at https://share.streamlit.io/ and select `app.py`. The public app URL can be opened on desktop and mobile browsers.

## Important limitations

- This is a browser-based responsive app, not a native Android/iOS app and not an app-store release.
- NOAA feeds can occasionally be unavailable or change format. The app shows feed errors and warns when data is incomplete.
- Risk scores are transparent demonstration heuristics, not validated ML predictions or official aviation risk classifications.
- Kp is a global geomagnetic indicator; it is not a local route-level GNSS scintillation measurement.
- The route line is illustrative and must not be used for navigation.
- Never use this prototype for dispatch, flight planning, crew radiation decisions, or other operational aviation decisions.
